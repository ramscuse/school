<!DOCTYPE html>
<html>
    <header>
        <h1>404 &mdash; OOPSIE WOOPSIE!!</h1>
    </header>

    <body>
       <main>
          <img src='<?php echo Asset::get_file('monke.png', 'img');?>'alt='a fucky wucky monkey' style='display:block;margin-left:auto;margin-right:auto'>
          <p style='text-align:center'>UwU We made a fucky wucky!! A wittle fucko boingo! The code monkeys at our headquarters are working <emph>VEWY HAWD</emph> to fix this!</p>
       </main>
    </body>
</html>
