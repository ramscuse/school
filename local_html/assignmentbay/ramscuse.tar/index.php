<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="east/style.css">
    </head>
    
    <nav>
        <ul class="nav-ul">
            <li><a href="east/index.php">East</a></li>
            <li><a href="west/index.php">West</a></li>
        </ul>
    </nav>

    <header>
        <h1>Jameson Walter</h1>
    </header>

    <body>
        <div>
            <p>Hello. Welcome to my east and west assignment. There will be no way to return to this page once you select a direction. :)</p>
        </div>
    </body>

    <footer>
        <h3>LOCAL</h3>
    </footer>
</html>